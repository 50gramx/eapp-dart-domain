//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/identity/space_things/delete_space_things.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use deleteThingsSpaceDomainRequestDescriptor instead')
const DeleteThingsSpaceDomainRequest$json = {
  '1': 'DeleteThingsSpaceDomainRequest',
  '2': [
    {'1': 'name', '3': 1, '4': 1, '5': 9, '10': 'name'},
  ],
};

/// Descriptor for `DeleteThingsSpaceDomainRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteThingsSpaceDomainRequestDescriptor = $convert.base64Decode(
    'Ch5EZWxldGVUaGluZ3NTcGFjZURvbWFpblJlcXVlc3QSEgoEbmFtZRgBIAEoCVIEbmFtZQ==');

@$core.Deprecated('Use deleteThingsSpaceDomainResponseDescriptor instead')
const DeleteThingsSpaceDomainResponse$json = {
  '1': 'DeleteThingsSpaceDomainResponse',
  '2': [
    {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
  ],
};

/// Descriptor for `DeleteThingsSpaceDomainResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteThingsSpaceDomainResponseDescriptor = $convert.base64Decode(
    'Ch9EZWxldGVUaGluZ3NTcGFjZURvbWFpblJlc3BvbnNlEhgKB3N1Y2Nlc3MYASABKAhSB3N1Y2'
    'Nlc3M=');

@$core.Deprecated('Use deleteNodesCollarRequestDescriptor instead')
const DeleteNodesCollarRequest$json = {
  '1': 'DeleteNodesCollarRequest',
  '2': [
    {'1': 'machine_class', '3': 1, '4': 1, '5': 9, '10': 'machineClass'},
  ],
};

/// Descriptor for `DeleteNodesCollarRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteNodesCollarRequestDescriptor = $convert.base64Decode(
    'ChhEZWxldGVOb2Rlc0NvbGxhclJlcXVlc3QSIwoNbWFjaGluZV9jbGFzcxgBIAEoCVIMbWFjaG'
    'luZUNsYXNz');

@$core.Deprecated('Use deleteNodesCollarResponseDescriptor instead')
const DeleteNodesCollarResponse$json = {
  '1': 'DeleteNodesCollarResponse',
  '2': [
    {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
  ],
};

/// Descriptor for `DeleteNodesCollarResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteNodesCollarResponseDescriptor = $convert.base64Decode(
    'ChlEZWxldGVOb2Rlc0NvbGxhclJlc3BvbnNlEhgKB3N1Y2Nlc3MYASABKAhSB3N1Y2Nlc3M=');

