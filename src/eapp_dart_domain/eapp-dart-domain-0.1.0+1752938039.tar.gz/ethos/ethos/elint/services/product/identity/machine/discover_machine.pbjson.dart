//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/identity/machine/discover_machine.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use listAllMachinesResponseDescriptor instead')
const ListAllMachinesResponse$json = {
  '1': 'ListAllMachinesResponse',
  '2': [
    {'1': 'machines', '3': 1, '4': 3, '5': 11, '6': '.elint.entity.Machine', '10': 'machines'},
    {'1': 'response_meta', '3': 2, '4': 1, '5': 11, '6': '.elint.entity.ResponseMeta', '10': 'responseMeta'},
  ],
};

/// Descriptor for `ListAllMachinesResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List listAllMachinesResponseDescriptor = $convert.base64Decode(
    'ChdMaXN0QWxsTWFjaGluZXNSZXNwb25zZRIxCghtYWNoaW5lcxgBIAMoCzIVLmVsaW50LmVudG'
    'l0eS5NYWNoaW5lUghtYWNoaW5lcxI/Cg1yZXNwb25zZV9tZXRhGAIgASgLMhouZWxpbnQuZW50'
    'aXR5LlJlc3BvbnNlTWV0YVIMcmVzcG9uc2VNZXRh');

