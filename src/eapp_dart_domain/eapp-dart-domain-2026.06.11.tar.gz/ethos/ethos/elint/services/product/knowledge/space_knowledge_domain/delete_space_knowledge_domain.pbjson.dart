//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/knowledge/space_knowledge_domain/delete_space_knowledge_domain.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use deleteSpaceKnowledgeDomainRequestDescriptor instead')
const DeleteSpaceKnowledgeDomainRequest$json = {
  '1': 'DeleteSpaceKnowledgeDomainRequest',
};

/// Descriptor for `DeleteSpaceKnowledgeDomainRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteSpaceKnowledgeDomainRequestDescriptor = $convert.base64Decode(
    'CiFEZWxldGVTcGFjZUtub3dsZWRnZURvbWFpblJlcXVlc3Q=');

@$core.Deprecated('Use deleteSpaceKnowledgeDomainResponseDescriptor instead')
const DeleteSpaceKnowledgeDomainResponse$json = {
  '1': 'DeleteSpaceKnowledgeDomainResponse',
};

/// Descriptor for `DeleteSpaceKnowledgeDomainResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteSpaceKnowledgeDomainResponseDescriptor = $convert.base64Decode(
    'CiJEZWxldGVTcGFjZUtub3dsZWRnZURvbWFpblJlc3BvbnNl');

