//
//  Generated code. Do not modify.
//  source: ethos/elint/entities/universe.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use universeDescriptor instead')
const Universe$json = {
  '1': 'Universe',
  '2': [
    {'1': 'universe_id', '3': 1, '4': 1, '5': 9, '10': 'universeId'},
    {'1': 'universe_name', '3': 2, '4': 1, '5': 9, '10': 'universeName'},
    {'1': 'universe_created_at', '3': 3, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'universeCreatedAt'},
    {'1': 'universe_description', '3': 4, '4': 1, '5': 9, '10': 'universeDescription'},
    {'1': 'universe_updated_at', '3': 5, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'universeUpdatedAt'},
  ],
};

/// Descriptor for `Universe`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List universeDescriptor = $convert.base64Decode(
    'CghVbml2ZXJzZRIfCgt1bml2ZXJzZV9pZBgBIAEoCVIKdW5pdmVyc2VJZBIjCg11bml2ZXJzZV'
    '9uYW1lGAIgASgJUgx1bml2ZXJzZU5hbWUSSgoTdW5pdmVyc2VfY3JlYXRlZF9hdBgDIAEoCzIa'
    'Lmdvb2dsZS5wcm90b2J1Zi5UaW1lc3RhbXBSEXVuaXZlcnNlQ3JlYXRlZEF0EjEKFHVuaXZlcn'
    'NlX2Rlc2NyaXB0aW9uGAQgASgJUhN1bml2ZXJzZURlc2NyaXB0aW9uEkoKE3VuaXZlcnNlX3Vw'
    'ZGF0ZWRfYXQYBSABKAsyGi5nb29nbGUucHJvdG9idWYuVGltZXN0YW1wUhF1bml2ZXJzZVVwZG'
    'F0ZWRBdA==');

