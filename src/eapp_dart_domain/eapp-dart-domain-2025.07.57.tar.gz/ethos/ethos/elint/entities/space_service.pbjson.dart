//
//  Generated code. Do not modify.
//  source: ethos/elint/entities/space_service.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use spaceServiceDescriptor instead')
const SpaceService$json = {
  '1': 'SpaceService',
  '2': [
    {'1': 'space_service_name', '3': 1, '4': 1, '5': 9, '10': 'spaceServiceName'},
    {'1': 'space_service_id', '3': 2, '4': 1, '5': 9, '10': 'spaceServiceId'},
    {'1': 'space_service_admin_account_id', '3': 3, '4': 1, '5': 9, '10': 'spaceServiceAdminAccountId'},
    {'1': 'space', '3': 4, '4': 1, '5': 11, '6': '.elint.entity.Space', '10': 'space'},
    {'1': 'created_at', '3': 5, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'createdAt'},
  ],
};

/// Descriptor for `SpaceService`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List spaceServiceDescriptor = $convert.base64Decode(
    'CgxTcGFjZVNlcnZpY2USLAoSc3BhY2Vfc2VydmljZV9uYW1lGAEgASgJUhBzcGFjZVNlcnZpY2'
    'VOYW1lEigKEHNwYWNlX3NlcnZpY2VfaWQYAiABKAlSDnNwYWNlU2VydmljZUlkEkIKHnNwYWNl'
    'X3NlcnZpY2VfYWRtaW5fYWNjb3VudF9pZBgDIAEoCVIac3BhY2VTZXJ2aWNlQWRtaW5BY2NvdW'
    '50SWQSKQoFc3BhY2UYBCABKAsyEy5lbGludC5lbnRpdHkuU3BhY2VSBXNwYWNlEjkKCmNyZWF0'
    'ZWRfYXQYBSABKAsyGi5nb29nbGUucHJvdG9idWYuVGltZXN0YW1wUgljcmVhdGVkQXQ=');

