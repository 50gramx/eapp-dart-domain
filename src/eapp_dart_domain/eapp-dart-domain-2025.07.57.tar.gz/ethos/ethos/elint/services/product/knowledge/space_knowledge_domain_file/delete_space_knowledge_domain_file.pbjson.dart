//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/knowledge/space_knowledge_domain_file/delete_space_knowledge_domain_file.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use deleteSpaceKnowledgeDomainFileRequestDescriptor instead')
const DeleteSpaceKnowledgeDomainFileRequest$json = {
  '1': 'DeleteSpaceKnowledgeDomainFileRequest',
  '2': [
    {'1': 'space_knowledge_domain_services_access_auth_details', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.knowledge.domain.SpaceKnowledgeDomainServicesAccessAuthDetails', '10': 'spaceKnowledgeDomainServicesAccessAuthDetails'},
    {'1': 'space_knowledge_domain_file', '3': 2, '4': 1, '5': 11, '6': '.elint.entity.SpaceKnowledgeDomainFile', '10': 'spaceKnowledgeDomainFile'},
  ],
};

/// Descriptor for `DeleteSpaceKnowledgeDomainFileRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteSpaceKnowledgeDomainFileRequestDescriptor = $convert.base64Decode(
    'CiVEZWxldGVTcGFjZUtub3dsZWRnZURvbWFpbkZpbGVSZXF1ZXN0EsIBCjNzcGFjZV9rbm93bG'
    'VkZ2VfZG9tYWluX3NlcnZpY2VzX2FjY2Vzc19hdXRoX2RldGFpbHMYASABKAsyVi5lbGludC5z'
    'ZXJ2aWNlcy5wcm9kdWN0Lmtub3dsZWRnZS5kb21haW4uU3BhY2VLbm93bGVkZ2VEb21haW5TZX'
    'J2aWNlc0FjY2Vzc0F1dGhEZXRhaWxzUi1zcGFjZUtub3dsZWRnZURvbWFpblNlcnZpY2VzQWNj'
    'ZXNzQXV0aERldGFpbHMSZQobc3BhY2Vfa25vd2xlZGdlX2RvbWFpbl9maWxlGAIgASgLMiYuZW'
    'xpbnQuZW50aXR5LlNwYWNlS25vd2xlZGdlRG9tYWluRmlsZVIYc3BhY2VLbm93bGVkZ2VEb21h'
    'aW5GaWxl');

