//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/service/space_service_domain/create_space_service_domain.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use createDC499999998SSDRequestDescriptor instead')
const CreateDC499999998SSDRequest$json = {
  '1': 'CreateDC499999998SSDRequest',
  '2': [
    {'1': 'auth', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.service.space.SpaceServiceServicesAccessAuthDetails', '10': 'auth'},
    {'1': 'name', '3': 2, '4': 1, '5': 9, '10': 'name'},
    {'1': 'description', '3': 3, '4': 1, '5': 9, '10': 'description'},
    {'1': 'is_isolated', '3': 4, '4': 1, '5': 8, '10': 'isIsolated'},
    {'1': 'dc499999998', '3': 5, '4': 1, '5': 11, '6': '.elint.collars.DC499999998', '10': 'dc499999998'},
  ],
};

/// Descriptor for `CreateDC499999998SSDRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List createDC499999998SSDRequestDescriptor = $convert.base64Decode(
    'ChtDcmVhdGVEQzQ5OTk5OTk5OFNTRFJlcXVlc3QSXwoEYXV0aBgBIAEoCzJLLmVsaW50LnNlcn'
    'ZpY2VzLnByb2R1Y3Quc2VydmljZS5zcGFjZS5TcGFjZVNlcnZpY2VTZXJ2aWNlc0FjY2Vzc0F1'
    'dGhEZXRhaWxzUgRhdXRoEhIKBG5hbWUYAiABKAlSBG5hbWUSIAoLZGVzY3JpcHRpb24YAyABKA'
    'lSC2Rlc2NyaXB0aW9uEh8KC2lzX2lzb2xhdGVkGAQgASgIUgppc0lzb2xhdGVkEjwKC2RjNDk5'
    'OTk5OTk4GAUgASgLMhouZWxpbnQuY29sbGFycy5EQzQ5OTk5OTk5OFILZGM0OTk5OTk5OTg=');

@$core.Deprecated('Use createDC499999999SSDRequestDescriptor instead')
const CreateDC499999999SSDRequest$json = {
  '1': 'CreateDC499999999SSDRequest',
  '2': [
    {'1': 'auth', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.service.space.SpaceServiceServicesAccessAuthDetails', '10': 'auth'},
    {'1': 'name', '3': 2, '4': 1, '5': 9, '10': 'name'},
    {'1': 'description', '3': 3, '4': 1, '5': 9, '10': 'description'},
    {'1': 'is_isolated', '3': 4, '4': 1, '5': 8, '10': 'isIsolated'},
    {'1': 'dc499999999', '3': 5, '4': 1, '5': 11, '6': '.elint.collars.DC499999999', '10': 'dc499999999'},
  ],
};

/// Descriptor for `CreateDC499999999SSDRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List createDC499999999SSDRequestDescriptor = $convert.base64Decode(
    'ChtDcmVhdGVEQzQ5OTk5OTk5OVNTRFJlcXVlc3QSXwoEYXV0aBgBIAEoCzJLLmVsaW50LnNlcn'
    'ZpY2VzLnByb2R1Y3Quc2VydmljZS5zcGFjZS5TcGFjZVNlcnZpY2VTZXJ2aWNlc0FjY2Vzc0F1'
    'dGhEZXRhaWxzUgRhdXRoEhIKBG5hbWUYAiABKAlSBG5hbWUSIAoLZGVzY3JpcHRpb24YAyABKA'
    'lSC2Rlc2NyaXB0aW9uEh8KC2lzX2lzb2xhdGVkGAQgASgIUgppc0lzb2xhdGVkEjwKC2RjNDk5'
    'OTk5OTk5GAUgASgLMhouZWxpbnQuY29sbGFycy5EQzQ5OTk5OTk5OVILZGM0OTk5OTk5OTk=');

