//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/product/space_product/delete_space_product.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use deleteSpaceProductRequestDescriptor instead')
const DeleteSpaceProductRequest$json = {
  '1': 'DeleteSpaceProductRequest',
};

/// Descriptor for `DeleteSpaceProductRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteSpaceProductRequestDescriptor = $convert.base64Decode(
    'ChlEZWxldGVTcGFjZVByb2R1Y3RSZXF1ZXN0');

@$core.Deprecated('Use deleteSpaceProductResponseDescriptor instead')
const DeleteSpaceProductResponse$json = {
  '1': 'DeleteSpaceProductResponse',
};

/// Descriptor for `DeleteSpaceProductResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List deleteSpaceProductResponseDescriptor = $convert.base64Decode(
    'ChpEZWxldGVTcGFjZVByb2R1Y3RSZXNwb25zZQ==');

