//
//  Generated code. Do not modify.
//  source: ethos/elint/services/product/product/space_product_domain/create_space_product_domain.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use createDC499999994SPDRequestDescriptor instead')
const CreateDC499999994SPDRequest$json = {
  '1': 'CreateDC499999994SPDRequest',
  '2': [
    {'1': 'auth', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.product.space.SpaceProductServicesAccessAuthDetails', '10': 'auth'},
    {'1': 'name', '3': 11, '4': 1, '5': 9, '10': 'name'},
    {'1': 'description', '3': 12, '4': 1, '5': 9, '10': 'description'},
    {'1': 'is_isolated', '3': 13, '4': 1, '5': 8, '10': 'isIsolated'},
    {'1': 'dc499999994', '3': 14, '4': 1, '5': 11, '6': '.elint.collars.DC499999994', '10': 'dc499999994'},
  ],
};

/// Descriptor for `CreateDC499999994SPDRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List createDC499999994SPDRequestDescriptor = $convert.base64Decode(
    'ChtDcmVhdGVEQzQ5OTk5OTk5NFNQRFJlcXVlc3QSXwoEYXV0aBgBIAEoCzJLLmVsaW50LnNlcn'
    'ZpY2VzLnByb2R1Y3QucHJvZHVjdC5zcGFjZS5TcGFjZVByb2R1Y3RTZXJ2aWNlc0FjY2Vzc0F1'
    'dGhEZXRhaWxzUgRhdXRoEhIKBG5hbWUYCyABKAlSBG5hbWUSIAoLZGVzY3JpcHRpb24YDCABKA'
    'lSC2Rlc2NyaXB0aW9uEh8KC2lzX2lzb2xhdGVkGA0gASgIUgppc0lzb2xhdGVkEjwKC2RjNDk5'
    'OTk5OTk0GA4gASgLMhouZWxpbnQuY29sbGFycy5EQzQ5OTk5OTk5NFILZGM0OTk5OTk5OTQ=');

