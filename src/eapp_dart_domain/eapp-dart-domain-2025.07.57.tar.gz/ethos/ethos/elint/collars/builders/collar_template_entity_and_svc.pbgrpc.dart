//
//  Generated code. Do not modify.
//  source: ethos/elint/collars/builders/collar_template_entity_and_svc.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:async' as $async;
import 'dart:core' as $core;

import 'package:grpc/service_api.dart' as $grpc;
import 'package:protobuf/protobuf.dart' as $pb;

export 'collar_template_entity_and_svc.pb.dart';

@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5000Capabilities')
class DC49999XXXXEPME5000CapabilitiesClient extends $grpc.Client {

  DC49999XXXXEPME5000CapabilitiesClient($grpc.ClientChannel channel,
      {$grpc.CallOptions? options,
      $core.Iterable<$grpc.ClientInterceptor>? interceptors})
      : super(channel, options: options,
        interceptors: interceptors);
}

@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5000Capabilities')
abstract class DC49999XXXXEPME5000CapabilitiesServiceBase extends $grpc.Service {
  $core.String get $name => 'elint.collars.DC49999XXXXEPME5000Capabilities';

  DC49999XXXXEPME5000CapabilitiesServiceBase() {
  }

}
@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5001Capabilities')
class DC49999XXXXEPME5001CapabilitiesClient extends $grpc.Client {

  DC49999XXXXEPME5001CapabilitiesClient($grpc.ClientChannel channel,
      {$grpc.CallOptions? options,
      $core.Iterable<$grpc.ClientInterceptor>? interceptors})
      : super(channel, options: options,
        interceptors: interceptors);
}

@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5001Capabilities')
abstract class DC49999XXXXEPME5001CapabilitiesServiceBase extends $grpc.Service {
  $core.String get $name => 'elint.collars.DC49999XXXXEPME5001Capabilities';

  DC49999XXXXEPME5001CapabilitiesServiceBase() {
  }

}
@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5002Capabilities')
class DC49999XXXXEPME5002CapabilitiesClient extends $grpc.Client {

  DC49999XXXXEPME5002CapabilitiesClient($grpc.ClientChannel channel,
      {$grpc.CallOptions? options,
      $core.Iterable<$grpc.ClientInterceptor>? interceptors})
      : super(channel, options: options,
        interceptors: interceptors);
}

@$pb.GrpcServiceName('elint.collars.DC49999XXXXEPME5002Capabilities')
abstract class DC49999XXXXEPME5002CapabilitiesServiceBase extends $grpc.Service {
  $core.String get $name => 'elint.collars.DC49999XXXXEPME5002Capabilities';

  DC49999XXXXEPME5002CapabilitiesServiceBase() {
  }

}
