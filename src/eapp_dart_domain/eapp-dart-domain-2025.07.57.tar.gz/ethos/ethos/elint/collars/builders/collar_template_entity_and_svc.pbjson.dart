//
//  Generated code. Do not modify.
//  source: ethos/elint/collars/builders/collar_template_entity_and_svc.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use dC49999XXXXDescriptor instead')
const DC49999XXXX$json = {
  '1': 'DC49999XXXX',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    {'1': 'name', '3': 2, '4': 1, '5': 9, '10': 'name'},
    {'1': 'description', '3': 3, '4': 1, '5': 9, '10': 'description'},
    {'1': 'collar_first_entity', '3': 5000, '4': 1, '5': 11, '6': '.elint.collars.CollarFirstEntity', '10': 'collarFirstEntity'},
    {'1': 'created_at', '3': 5, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'createdAt'},
    {'1': 'updated_at', '3': 6, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'updatedAt'},
  ],
};

/// Descriptor for `DC49999XXXX`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List dC49999XXXXDescriptor = $convert.base64Decode(
    'CgtEQzQ5OTk5WFhYWBIOCgJpZBgBIAEoCVICaWQSEgoEbmFtZRgCIAEoCVIEbmFtZRIgCgtkZX'
    'NjcmlwdGlvbhgDIAEoCVILZGVzY3JpcHRpb24SUQoTY29sbGFyX2ZpcnN0X2VudGl0eRiIJyAB'
    'KAsyIC5lbGludC5jb2xsYXJzLkNvbGxhckZpcnN0RW50aXR5UhFjb2xsYXJGaXJzdEVudGl0eR'
    'I5CgpjcmVhdGVkX2F0GAUgASgLMhouZ29vZ2xlLnByb3RvYnVmLlRpbWVzdGFtcFIJY3JlYXRl'
    'ZEF0EjkKCnVwZGF0ZWRfYXQYBiABKAsyGi5nb29nbGUucHJvdG9idWYuVGltZXN0YW1wUgl1cG'
    'RhdGVkQXQ=');

@$core.Deprecated('Use collarFirstEntityDescriptor instead')
const CollarFirstEntity$json = {
  '1': 'CollarFirstEntity',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    {'1': 'dummy', '3': 2, '4': 1, '5': 9, '10': 'dummy'},
    {'1': 'yet_another_collar_entity', '3': 5001, '4': 3, '5': 11, '6': '.elint.collars.YetAnotherCollarEntity', '10': 'yetAnotherCollarEntity'},
  ],
};

/// Descriptor for `CollarFirstEntity`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List collarFirstEntityDescriptor = $convert.base64Decode(
    'ChFDb2xsYXJGaXJzdEVudGl0eRIOCgJpZBgBIAEoCVICaWQSFAoFZHVtbXkYAiABKAlSBWR1bW'
    '15EmEKGXlldF9hbm90aGVyX2NvbGxhcl9lbnRpdHkYiScgAygLMiUuZWxpbnQuY29sbGFycy5Z'
    'ZXRBbm90aGVyQ29sbGFyRW50aXR5UhZ5ZXRBbm90aGVyQ29sbGFyRW50aXR5');

@$core.Deprecated('Use yetAnotherCollarEntityDescriptor instead')
const YetAnotherCollarEntity$json = {
  '1': 'YetAnotherCollarEntity',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
  ],
};

/// Descriptor for `YetAnotherCollarEntity`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List yetAnotherCollarEntityDescriptor = $convert.base64Decode(
    'ChZZZXRBbm90aGVyQ29sbGFyRW50aXR5Eg4KAmlkGAEgASgJUgJpZA==');

