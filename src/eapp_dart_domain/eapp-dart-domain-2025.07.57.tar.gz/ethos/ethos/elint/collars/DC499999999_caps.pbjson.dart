//
//  Generated code. Do not modify.
//  source: ethos/elint/collars/DC499999999_caps.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use authWithDeploymentDescriptor instead')
const AuthWithDeployment$json = {
  '1': 'AuthWithDeployment',
  '2': [
    {'1': 'auth', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.service.domain.SpaceServiceDomainServicesAccessAuthDetails', '10': 'auth'},
    {'1': 'deployment', '3': 2, '4': 1, '5': 11, '6': '.elint.collars.Deployment', '10': 'deployment'},
  ],
};

/// Descriptor for `AuthWithDeployment`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List authWithDeploymentDescriptor = $convert.base64Decode(
    'ChJBdXRoV2l0aERlcGxveW1lbnQSZgoEYXV0aBgBIAEoCzJSLmVsaW50LnNlcnZpY2VzLnByb2'
    'R1Y3Quc2VydmljZS5kb21haW4uU3BhY2VTZXJ2aWNlRG9tYWluU2VydmljZXNBY2Nlc3NBdXRo'
    'RGV0YWlsc1IEYXV0aBI5CgpkZXBsb3ltZW50GAIgASgLMhkuZWxpbnQuY29sbGFycy5EZXBsb3'
    'ltZW50UgpkZXBsb3ltZW50');

@$core.Deprecated('Use repeatedDC499999999Descriptor instead')
const RepeatedDC499999999$json = {
  '1': 'RepeatedDC499999999',
  '2': [
    {'1': 'meta', '3': 1, '4': 1, '5': 11, '6': '.elint.entity.ResponseMeta', '10': 'meta'},
    {'1': 'collars', '3': 2, '4': 3, '5': 11, '6': '.elint.collars.DC499999999', '10': 'collars'},
  ],
};

/// Descriptor for `RepeatedDC499999999`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List repeatedDC499999999Descriptor = $convert.base64Decode(
    'ChNSZXBlYXRlZERDNDk5OTk5OTk5Ei4KBG1ldGEYASABKAsyGi5lbGludC5lbnRpdHkuUmVzcG'
    '9uc2VNZXRhUgRtZXRhEjQKB2NvbGxhcnMYAiADKAsyGi5lbGludC5jb2xsYXJzLkRDNDk5OTk5'
    'OTk5Ugdjb2xsYXJz');

@$core.Deprecated('Use sSDAuthWithCollarIDDescriptor instead')
const SSDAuthWithCollarID$json = {
  '1': 'SSDAuthWithCollarID',
  '2': [
    {'1': 'auth', '3': 1, '4': 1, '5': 11, '6': '.elint.services.product.service.domain.SpaceServiceDomainServicesAccessAuthDetails', '10': 'auth'},
    {'1': 'collar_id', '3': 2, '4': 1, '5': 9, '10': 'collarId'},
  ],
};

/// Descriptor for `SSDAuthWithCollarID`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List sSDAuthWithCollarIDDescriptor = $convert.base64Decode(
    'ChNTU0RBdXRoV2l0aENvbGxhcklEEmYKBGF1dGgYASABKAsyUi5lbGludC5zZXJ2aWNlcy5wcm'
    '9kdWN0LnNlcnZpY2UuZG9tYWluLlNwYWNlU2VydmljZURvbWFpblNlcnZpY2VzQWNjZXNzQXV0'
    'aERldGFpbHNSBGF1dGgSGwoJY29sbGFyX2lkGAIgASgJUghjb2xsYXJJZA==');

