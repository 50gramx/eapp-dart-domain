//
//  Generated code. Do not modify.
//  source: ethos/elint/collars/DC499999996.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use dC499999996Descriptor instead')
const DC499999996$json = {
  '1': 'DC499999996',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    {'1': 'name', '3': 2, '4': 1, '5': 9, '10': 'name'},
    {'1': 'description', '3': 3, '4': 1, '5': 9, '10': 'description'},
    {'1': 'jupyter_notebook', '3': 5000, '4': 1, '5': 11, '6': '.elint.collars.JupyterNotebook', '10': 'jupyterNotebook'},
    {'1': 'created_at', '3': 5, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'createdAt'},
    {'1': 'updated_at', '3': 6, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'updatedAt'},
  ],
};

/// Descriptor for `DC499999996`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List dC499999996Descriptor = $convert.base64Decode(
    'CgtEQzQ5OTk5OTk5NhIOCgJpZBgBIAEoCVICaWQSEgoEbmFtZRgCIAEoCVIEbmFtZRIgCgtkZX'
    'NjcmlwdGlvbhgDIAEoCVILZGVzY3JpcHRpb24SSgoQanVweXRlcl9ub3RlYm9vaxiIJyABKAsy'
    'Hi5lbGludC5jb2xsYXJzLkp1cHl0ZXJOb3RlYm9va1IPanVweXRlck5vdGVib29rEjkKCmNyZW'
    'F0ZWRfYXQYBSABKAsyGi5nb29nbGUucHJvdG9idWYuVGltZXN0YW1wUgljcmVhdGVkQXQSOQoK'
    'dXBkYXRlZF9hdBgGIAEoCzIaLmdvb2dsZS5wcm90b2J1Zi5UaW1lc3RhbXBSCXVwZGF0ZWRBdA'
    '==');

@$core.Deprecated('Use jupyterNotebookDescriptor instead')
const JupyterNotebook$json = {
  '1': 'JupyterNotebook',
  '2': [
    {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
  ],
};

/// Descriptor for `JupyterNotebook`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List jupyterNotebookDescriptor = $convert.base64Decode(
    'Cg9KdXB5dGVyTm90ZWJvb2sSDgoCaWQYASABKAlSAmlk');

@$core.Deprecated('Use launchNotebookRequestDescriptor instead')
const LaunchNotebookRequest$json = {
  '1': 'LaunchNotebookRequest',
};

/// Descriptor for `LaunchNotebookRequest`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List launchNotebookRequestDescriptor = $convert.base64Decode(
    'ChVMYXVuY2hOb3RlYm9va1JlcXVlc3Q=');

@$core.Deprecated('Use launchNotebookResponseDescriptor instead')
const LaunchNotebookResponse$json = {
  '1': 'LaunchNotebookResponse',
};

/// Descriptor for `LaunchNotebookResponse`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List launchNotebookResponseDescriptor = $convert.base64Decode(
    'ChZMYXVuY2hOb3RlYm9va1Jlc3BvbnNl');

