//
//  Generated code. Do not modify.
//  source: ethos/elint/entities/space_things.proto
//
// @dart = 2.12

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_final_fields
// ignore_for_file: unnecessary_import, unnecessary_this, unused_import

import 'dart:convert' as $convert;
import 'dart:core' as $core;
import 'dart:typed_data' as $typed_data;

@$core.Deprecated('Use spaceThingsDescriptor instead')
const SpaceThings$json = {
  '1': 'SpaceThings',
  '2': [
    {'1': 'name', '3': 1, '4': 1, '5': 9, '10': 'name'},
    {'1': 'id', '3': 2, '4': 1, '5': 9, '10': 'id'},
    {'1': 'admin', '3': 3, '4': 1, '5': 11, '6': '.elint.entity.Account', '10': 'admin'},
    {'1': 'space', '3': 4, '4': 1, '5': 11, '6': '.elint.entity.Space', '10': 'space'},
    {'1': 'created_at', '3': 5, '4': 1, '5': 11, '6': '.google.protobuf.Timestamp', '10': 'createdAt'},
  ],
};

/// Descriptor for `SpaceThings`. Decode as a `google.protobuf.DescriptorProto`.
final $typed_data.Uint8List spaceThingsDescriptor = $convert.base64Decode(
    'CgtTcGFjZVRoaW5ncxISCgRuYW1lGAEgASgJUgRuYW1lEg4KAmlkGAIgASgJUgJpZBIrCgVhZG'
    '1pbhgDIAEoCzIVLmVsaW50LmVudGl0eS5BY2NvdW50UgVhZG1pbhIpCgVzcGFjZRgEIAEoCzIT'
    'LmVsaW50LmVudGl0eS5TcGFjZVIFc3BhY2USOQoKY3JlYXRlZF9hdBgFIAEoCzIaLmdvb2dsZS'
    '5wcm90b2J1Zi5UaW1lc3RhbXBSCWNyZWF0ZWRBdA==');

