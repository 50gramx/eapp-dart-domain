import 'package:eapp_dart_domain/eapp_dart_domain.dart';

void main() {
  var awesome = Awesome();
  print('awesome: ${awesome.isAwesome}');
}
